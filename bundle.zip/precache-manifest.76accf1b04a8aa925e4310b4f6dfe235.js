self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7f959bc6d84016ebd54275ef374a2118",
    "url": "/vk-test/index.html"
  },
  {
    "revision": "a1e739b5413788921543",
    "url": "/vk-test/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "a1e739b5413788921543",
    "url": "/vk-test/static/js/2.0012b232.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/vk-test/static/js/2.0012b232.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f83a9ddd1ab341bfdd17",
    "url": "/vk-test/static/js/main.69f92fdb.chunk.js"
  },
  {
    "revision": "4ed7ea38999b7f666f41",
    "url": "/vk-test/static/js/runtime-main.8af4aff8.js"
  }
]);